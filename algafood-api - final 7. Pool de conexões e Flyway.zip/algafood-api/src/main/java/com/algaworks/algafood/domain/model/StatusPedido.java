package com.algaworks.algafood.domain.model;

public enum StatusPedido {

    CRIADO,
    CONFIRMADO,
    ENTREGUE,
    CANCELADO
}